/**
 * jspsych-audio-mushra
 * audio Mushra test
 * modified from:
 * jspsych-audio-button-response
 * Josh de Leeuw
 *
 * plugin for playing multiple audios and
 *
 *
 * documentation: docs.jspsych.org
 *
 **/

jsPsych.plugins["audio-mushra-likert"] = (function() {

  var plugin = {};

  jsPsych.pluginAPI.registerPreload('audio-mushra-likert', 'stimulus', 'audio');

  plugin.info = {
    name: 'audio-mushra-likert',
    description: '',
    parameters: {
      test_name:{
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default: "audio-mushra-likert-test",
        description: 'The name of the test, part of the response'
      },
      audios: {
        type: jsPsych.plugins.parameterType.audio,
        pretty_name: 'Audios',
        default: undefined,
        description: 'The audio files to play.'
      },
      choices: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Choices',
        default: undefined,
        array: true,
        description: 'The labels for the buttons.'
      },
      button_html: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button HTML',
        default: '<button class="jspsych-btn">%choice%</button>',
        array: true,
        description: 'The html of the button. Can create own style.'
      },
      prompt: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Prompt',
        default: null,
        description: 'Any content here will be displayed below the buttons.'
      },
      // width: {
      //   type: jsPsych.plugins.parameterType.INT,
      //   pretty_name: 'Width',
      //   default: '',
      //   description: 'The width of the audio in pixels.'
      // },
      // height: {
      //   type: jsPsych.plugins.parameterType.INT,
      //   pretty_name: 'Height',
      //   default: '',
      //   description: 'The height of the audio display in pixels.'
      // },
      randomize: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Randomize the order of audios',
        default: true,
        description: 'If true, then the order of audios is randomized and the order is part of response'
      },
      // fade_speed: {
      //   type: jsPsych.plugins.parameterType.FLOAT,
      //   pretty_name: 'Fade speed',
      //   default: 20,
      //   description: 'Fade in/out speed: miliseconds to update opacity'
      // },
      // audio_background_color: {
      //   type: jsPsych.plugins.parameterType.STRING,
      //   pretty_name: 'audio background color',
      //   default: "#474747",
      //   description: 'The background of html audio element will be set to this color.'
      // },
      audio_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Audio volume',
        default: 0.02,
        description: 'Specify audio playing volume from 0.0 to 1.0'
      },
      max_audio_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Max audio volume',
        default: 0.20,
        description: 'Specify max audio playing volume from 0.0 to 1.0'
      },
      get_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Get overall volume function',
        default: null,
        description: 'function that returns current overall volume for the experiment'
      },
      change_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Change overall volume function',
        default: null,
        description: 'function to change overall volume for subsequent tests'
      },
      textbox_prompts: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Text box Prompts',
        default: [],
        description: 'Prompt to textbox input'
      },
    }
  }

  plugin.trial = function(display_element, trial) {
    var plugin_id_name = "jspsych-audio-mushra";

    var question_column_perc = 100 / trial.audios.length

    var audio_html = ""
    audio_html += '<style id="jspsych-survey-mushra-css">';
    audio_html +=
        ".jspsych-audio-mushra-likert-question {font-size: 12px; margin-top: 2em; margin-bottom: 4em; margin-right: 2em; text-align: left; }\n"+
        ".jspsych-audio-mushra-likert-question-small-margin {font-size: 12px; margin-top: 0em; margin-bottom: 1em; margin-right: 2em; text-align: left; }\n"+
        ".jspsych-audio-mushra-likert-text-left { font-size: 12px; text-align: left; width: 100px;}\n"+
        ".jspsych-audio-mushra-likert-text-right { font-size: 12px; text-align: right; width: 100px;}\n"+
        ".jspsych-audio-mushra-likert-option { line-height: 2;}\n"+
        ".make-row {line-height: 2; display: inline-flex; align-items: center; justify-content: flex-start;}\n"+
        ".question {white-space: nowrap;}\n"+
        ".dotrow {white-space: nowrap;}\n"+
        ".textbox {padding-bottom: 20px;}\n"+
        ".buttongroup {display: flex; justify-content: center;}\n"+
        ".text-box {width: -webkit-fill-available; height: 80px;}\n"+
        ".banner {display: flex; justify-content: space-between;}\n"+
        ".play-pause-group {}\n"+
        ".volume-slider {padding-left: 100px;}\n"+

         "  .tri_column {\n" +
        "    float: left;\n" +
        "    width: 33%;\n" +
        "  }\n" +
        "\n" +
         "  .five_column {\n" +
        "    float: left;\n" +
        "    width: 100%;\n" +
        "  }\n" +
        "\n" +
        "  .column {\n" +
        "    float: left;\n" +
        "    width: 50%;\n" +
        "  }\n" +
        "\n" +
        "  /* Clear floats after the columns */\n" +
        "  .row:after {\n" +
        "    content: \"\";\n" +
        "    display: table;\n" +
        "    clear: both;\n" +
        "  }"+
        "  .question_column {\n" +
        "    float: left;\n" +
        "    width: "+question_column_perc+"%;\n" +
        "    display: grid;\n"+
        "    grid-template-rows: auto auto auto;\n"+
        "    justify-items: center;\n"+
         "  }\n"        
         "\n" 
    audio_html += '</style>'

    // randomize audios
    var audio_order = []
    for (var i=0;i<trial.audios.length;i++)
    {
      audio_order.push(i)
    }
    if (trial.randomize){
      audio_order = jsPsych.randomization.shuffle(audio_order)
    }

    audio_html += '<div class= banner>'
    // add prompt if there is one
    if (trial.prompt !== null) {
      audio_html += '<h2 style= padding-right: 120px;>' + trial.prompt + '</h2>';
    }

    // place audio on top
    audio_html += '<div id="audio_div"><audio id="jspsych-audio-mushra-likert-audio"'

    if(trial.width) {
      audio_html += ' width="'+trial.width+'"';
    }
    if(trial.height) {
      audio_html += ' height="'+trial.height+'"';
    }
    audio_html +='>';

    var file_name = trial.audios[audio_order[0]];
    if(file_name.indexOf('?') > -1){
      file_name = file_name.substring(0, file_name.indexOf('?'));
    }
    var type = file_name.substr(file_name.lastIndexOf('.') + 1);
    type = type.toLowerCase();
    if (type == "mov") {
      console.warn('Warning: audio-mushra-likert plugin does not reliably support .mov files.')
    }
    audio_html+='<source src="' + file_name + '" type="audio/'+type+'">';
    // audio_html+='<source src="" type="audio/'+type+'">';

    audio_html += "</audio></div>";

    // volume slider
    audio_html += '<div class= volume-slider> <label for="audio_volume">Volume</label>'
    audio_html += '<input type="range" id="audio_volume" name="audio_volume" min="0" max="'+trial.max_audio_volume+'" step="0.002" value="'+trial.audio_volume+'"></input>'
    audio_html += '</div></div>'
    audio_html += '<form id="jspsych-audio-mushra-likert-form" autocomplete="off" style = "padding-bottom: 20px;">';

    // columns with audio play/stop buttons and corresponding choices
    audio_html += '<div class="row">'
    for (var i=0; i < trial.audios.length; i++) {
      
      audio_i = audio_order[i]
      var pretty_i = i+1
      audio_html += '<div class="question_column">'

      audio_html += '<div id="jspsych-audio-mushra-likert-audio-' + audio_i + '" class="jspsych-audio-mushra-likert-question"  data-name="audio-' + audio_i + '">';

      // audio_html += '<p style="text-align: center"><b>audio '+ pretty_i + '</b></p>'
      audio_html += '<p><b>audio '+ pretty_i + '</b></p>'

      // audio_html += '<div class=buttongroup>'
      audio_html += '<input type="button" id="play-btn-here-'+audio_i+'"  class="'+plugin_id_name+' jspsych-btn"' + ' value="play"></input> '; //style="font-weight:bold"
      audio_html += '<input type="button" id="stop-'+audio_i+'" class="'+plugin_id_name+' jspsych-btn"' + ' value="stop"' + '></input> <br>';
      // audio_html += '</div>'
      
      for (var j = 0; j < trial.choices.length; j++) {
        // add label and question text
        var question_id_name = "jspsych-audio-mushra-likert-question-" + audio_i + "-" + j;
        var required_attr = 'required'
        // add radio button container
        audio_html += '<div id="' + question_id_name + '" class="jspsych-audio-mushra-likert-question">';
        if (i == 0){
          audio_html += '<div class= "question">' + trial.choices[j][0] + '</div>'
        } else {
          audio_html += '<br>'
        }
        audio_html += '<div class="make-row">'
        audio_html += '<div class= "jspsych-audio-mushra-likert-text-left">' + trial.choices[j][1] + '</div>'
        audio_html += '<div class="dotrow">'
        for (var k=0; k < 11; k++) {
          var input_name = 'jspsych-audio-mushra-likert-response-' + audio_i+ '-' + j// + '-' + k;
          audio_html += '<input type="radio" name="' + input_name + '" id="response-' + audio_i + '-' + j + '-' + k + '" value="' + k + '" ' + required_attr + '></input>';
        }
        audio_html += '</div>'
        audio_html += '<div class= "jspsych-audio-mushra-likert-text-right">' + trial.choices[j][2] + '</div>'
        audio_html += '</div>';
        audio_html += '</div>';
      }
      audio_html += '</div>'
      audio_html += '</div>'
    }
    audio_html += '</div>'

    audio_html += '<br></br>'

    for (var i=0; i < trial.textbox_prompts.length; i++)
    {
      audio_html += '<div id=text_box'+i+' class=textbox>'
      audio_html += '<p class="jspsych-audio-mushra-likert-question-small-margin">' + trial.textbox_prompts[i] + '</p>';
      audio_html += '<textarea class=text-box id=text_box_input'+i+' type="text" required></textarea>' // style = "width: -webkit-fill-available;" 

      audio_html += '</div>'

      if (i == 0)
      {
        // ask favorite
        audio_html += '<div id="jspsych-audio-mushra-likert-favorite" class="jspsych-audio-mushra-likert-question-small-margin"  data-name="all">';
        audio_html += '<div class= "question"> Which one is your favorite? </div>'
        audio_html += '<div class="dotrow">'
        for (var k=0; k < 3; k++) {
          var input_name = 'jspsych-audio-mushra-likert-response-ranking-fav' // + '-' + k;
          audio_html += '<input type="radio" name="' + input_name + '" id="response-' + k + '" value="' + k + '" ' + required_attr + '> <b> audio ' + (k+1) + ' </b> </input>';
        }
        audio_html += '</div>'
        audio_html += '</div>'

        // ask least favorite
        audio_html += '<div id="jspsych-audio-mushra-likert-least-fav" class="jspsych-audio-mushra-likert-question-small-margin"  data-name="all">';
        audio_html += '<div class= "question"> Which one is your least favorite? </div>'
        audio_html += '<div class="dotrow">'
        for (var k=0; k < 3; k++) {
          var input_name = 'jspsych-audio-mushra-likert-response-ranking-least-fav' // + '-' + k;
          audio_html += '<input type="radio" name="' + input_name + '" id="response-' + k + '" value="' + k + '" ' + required_attr + '> <b> audio ' + (k+1) + ' </b> </input>';
        }
        audio_html += '</div>'
        audio_html += '</div>'
      }
    }

    // submit button
    audio_html += '<input type="submit" id="jspsych-audio-mushra-likert-next-submit" class="jspsych-audio-mushra-likert jspsych-btn" value="Continue"></input>';

    audio_html += '</form>'
    display_element.innerHTML = audio_html;
    
    // set audio element color
    var audio_element = display_element.querySelector('#jspsych-audio-mushra-likert-audio');
    audio_element.style["background-color"] = trial.audio_background_color
    var op = 0.0
    audio_element.style["opacity"] = op
    var audio_div = display_element.querySelector('#audio_div')
    audio_div.style["background-color"] = trial.audio_background_color
    audio_div.style["width"] = trial.width+"px"
    audio_div.style["height"] = trial.height+"px"

    // starting volume
    var audio_volume = trial.audio_volume
    if (trial.get_overall_volume !== null) {
      audio_volume = trial.get_overall_volume()
    }
    audio_element.volume = audio_volume

    // volume controller
    var volumeControl = document.querySelector('#audio_volume')
    volumeControl.value = audio_volume
    volumeControl.addEventListener('input', function(){
      audio_element.volume = this.value
      audio_volume = this.value
    })

    // fade in and fade out funcs
    var is_playing = false
    var is_fading = false
    fade_in = function() {
      timer = setInterval(function() {
          if (op >= 1) {
            op = 1.0
            audio_element.style["opacity"] = op
            audio_element.play()
            is_playing = true
            is_fading = false
            clearInterval(timer);
          }
          audio_element.style["opacity"] = op
          op += 0.05
        }, trial.fade_speed)
    }
    fade_out = function() {
      timer = setInterval(function() {
          if (op <= 0) {
            op = 0.0
            audio_element.style["opacity"] = op
            audio_element.pause()
            is_playing = false
            is_fading = false
            clearInterval(timer);
          }
          audio_element.style["opacity"] = op
          op -= 0.05
        }, trial.fade_speed)
    }

    var play_buttons = []
    var stop_buttons = []
    var playing_i = audio_order[0]
    var play_count = []
    for (var i = 0; i < trial.audios.length; i++) {
      play_count.push(0)
    }
    audio_element.onended = function(){
      fade_out()
      play_buttons[playing_i].style["color"] = "black"
      play_buttons[playing_i].style["background-color"] = "white"
    }
    for (var i = 0; i < trial.audios.length; i++) {
      // var question_id = question_order[i];
      var x = document.getElementById('play-btn-here-' + i);
      x.addEventListener("click", function (event) {
        // event.preventDefault();
        if (is_playing || is_fading){
          return
        }
        is_fading = true

        var audio_i = event.target.id.slice(-1)
        op = 0.0
        audio_element.style["opacity"] = op
        audio_element.src = trial.audios[audio_i]

        fade_in()

        event.target.style["color"] = 'white'
        event.target.style["background-color"] = 'blue'
        playing_i = audio_i
        play_count[audio_i] += 1
      })
      play_buttons.push(x)

      var x = document.getElementById('stop-'+i);
      x.addEventListener("click", function (event) {
        if (is_fading || (!is_playing)) {
          return
        }
        is_fading = true

        var button_i = event.target.id.slice(-1)
        play_buttons[playing_i].style["color"] = "black"
        play_buttons[playing_i].style["background-color"] = "white"

        audio_element.pause()
        fade_out()
      })
      stop_buttons.push(x)
    }

    // function to end trial when it is time
    function end_trial() {

      // kill any remaining setTimeout handlers
      // jsPsych.pluginAPI.clearAllTimeouts();

      // stop the audio
      audio_element.pause()

      var responses = {}

      // get multiple choice preference response
      for(var i=0; i<trial.audios.length; i++){
        audio_i = audio_order[i]
        for (var j = 0; j < trial.choices.length; j++) {
          var question_id_name = "jspsych-audio-mushra-likert-question-" + audio_i + "-" + j;

          var match = display_element.querySelector('#' + question_id_name);
          if (match.querySelector("input[type=radio]:checked") !== null) {
            var val = match.querySelector("input[type=radio]:checked").value;
          } else {
            window.alert("error: the test can not continue.")
            var val = "";
          }
          responses[''+audio_i+'-'+j] = val
        }
      }
      
      // get textbox response
      for(var i=0; i<trial.textbox_prompts.length; i++){
        var textbox_id = "text_box_input" + i;

        var match = display_element.querySelector('#' + textbox_id);
        var val = match.value;

        responses['text_box'+i] = val
        responses['text_box_prompt'+i] = trial.textbox_prompts[i]      
      }

      // get response on 'favorite' question
      var question_id_name = "jspsych-audio-mushra-likert-favorite";
      var match = display_element.querySelector('#' + question_id_name);
      var val = "";
      if (match.querySelector("input[type=radio]:checked") !== null) {
        val = match.querySelector("input[type=radio]:checked").value;
      } else {
        window.alert("error: the test can not continue.")
      }
      responses['favorite'] = audio_order[val]

      // get response on 'least favorite' question
      var question_id_name = "jspsych-audio-mushra-likert-least-fav";
      var match = display_element.querySelector('#' + question_id_name);
      var val = "";
      if (match.querySelector("input[type=radio]:checked") !== null) {
        val = match.querySelector("input[type=radio]:checked").value;
      } else {
        window.alert("error: the test can not continue.")
      }
      responses['least_favorite'] = audio_order[val]
      responses['play_count'] = play_count

      // gather the data to store for the trial
      var trial_data = {
        audios: trial.audios,
        response: responses,
        audio_order: audio_order,
        test_name: trial.test_name
      };

      // clear the display
      display_element.innerHTML = '';

      // set overall volume
      if (trial.change_overall_volume !== null){
        trial.change_overall_volume(audio_volume)
      }

      // move on to the next trial
      jsPsych.finishTrial(trial_data);
    }

    document.querySelector('form').addEventListener('submit', function(event) {
      // y.addEventListener("click", function(event) {
      event.preventDefault();

      end_trial();
    })
  };

  return plugin;
})();
