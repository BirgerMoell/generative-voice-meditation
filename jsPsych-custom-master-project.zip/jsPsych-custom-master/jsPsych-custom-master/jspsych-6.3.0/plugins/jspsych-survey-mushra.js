/**
 *
 * jspsych-survey-mushra
 * mushra-like listening test jspsych plugin
 *
 * adapted from jspsych-survey-multi-choice
 *
 */


jsPsych.plugins['survey-mushra'] = (function() {

  var plugin = {};

  plugin.info = {
    name: 'survey-mushra',
    description: '',
    parameters: {
      audios: {
        type: jsPsych.plugins.parameterType.COMPLEX,
        array: true,
        pretty_name: 'Audios',
        nested: {
          transcript: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Transcript',
            default: '',
            description: 'The transcripts will be placed in rows together at the bottom of the page.'
          },
          required: {
            type: jsPsych.plugins.parameterType.BOOL,
            pretty_name: 'Required',
            default: true,
            description: 'Subject will be required to give a rating for this audio. default:true.'
          },
          audio_name: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Audio Name',
            default: '',
            description: 'Full audio file name that is in the same directory as exp html file.'
          }
        }
      },
      options: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Options',
        array: true,
        default: ["5", "4", "3", "2", "1"],
        description: 'Mushra rating options'
      },
      randomize_audio_order: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Randomize Audio Order',
        default: false,
        description: 'If true, the order of the audios will be randomized. This does not affect recording results.'
      },
      preamble: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Preamble',
        default: null,
        description: 'HTML formatted string to display at the top of the page above all the questions.'
      },
      button_label: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button label',
        default:  'Continue',
        description: 'Label of the continue button.'
      },
      autocomplete: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Allow autocomplete',
        default: false,
        description: "Setting this to true will enable browser auto-complete or auto-fill for the form."
      },
      test_name: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default:  '',
        description: 'Name of test. Will be recorded as part of results.'
      },
      single_transcript: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Single Transcript',
        default: null,
        description: 'The single transcript.'
      },
      audio_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Audio volume',
        default: 0.02,
        description: 'Specify audio playing volume from 0.0 to 1.0'
      },
      max_audio_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Max audio volume',
        default: 0.20,
        description: 'Specify max audio playing volume from 0.0 to 1.0'
      },
      get_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Get overall volume function',
        default: null,
        description: 'function that returns current overall volume for the experiment'
      },
      change_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Change overall volume function',
        default: null,
        description: 'function to change overall volume for subsequent tests'
      }
    }
  }
  plugin.trial = function(display_element, trial) {

    if (trial.get_overall_volume !== null) {
      trial.audio_volume = trial.get_overall_volume()
    }

    var plugin_id_name = "jspsych-survey-mushra";

    var html = "";

    // inject CSS for trial
    html += '<style id="jspsych-survey-mushra-css">';
    html += ".jspsych-survey-mushra-question { margin-top: 2em; margin-bottom: 2em; text-align: left; }"+
      ".jspsych-survey-mushra-text span.required {color: darkred;}"+
      ".jspsych-survey-mushra-horizontal .jspsych-survey-mushra-text {  text-align: center;}"+
      ".jspsych-survey-mushra-option { line-height: 2; }"+
      ".jspsych-survey-mushra-horizontal .jspsych-survey-mushra-option {  display: inline-block;  margin-left: 1em;  margin-right: 1em;  vertical-align: top;}"+
      "label.jspsych-survey-mushra-text input[type='radio'] {margin-right: 1em;}"+
      "\n" +
        "  .column {\n" +
        "    float: left;\n" +
        "    width: 25%;\n" +
        "  }\n" +
        "\n" +
        "  /* Clear floats after the columns */\n" +
        "  .row:after {\n" +
        "    content: \"\";\n" +
        "    display: table;\n" +
        "    clear: both;\n" +
        "  }";
    html += '</style>';

    // show preamble text
    // trial.preamble =
    if(trial.preamble !== null){
      html += '<div id="jspsych-survey-mushra-preamble" class="jspsych-survey-mushra-preamble">'+trial.preamble+'</div>';
    }

    // volume slider
    html += '<label for="audio_volume">Volume</label>'
    html += '<input type="range" id="audio_volume" name="audio_volume" min="0" max="'+trial.max_audio_volume+'" step="0.01" value="'+trial.audio_volume+'"></input>'

    // form element
    if ( trial.autocomplete ) {
    	html += '<form id="jspsych-survey-mushra-form">';
    } else {
    	html += '<form id="jspsych-survey-mushra-form" autocomplete="off">';
    }
    // generate audio order. this is randomized here as opposed to randomizing the order of trial.audios
    // so that the data are always associated with the same audio regardless of order
    var audio_order = [];
    for(var i=0; i<trial.audios.length; i++){
      audio_order.push(i);
    }
    if(trial.randomize_audio_order){
      audio_order = jsPsych.randomization.shuffle(audio_order);
    }

    html += '<div class="row">'
    for (var i = 0; i < trial.audios.length; i++) {
      html += '<div class="column">'

      var audio = trial.audios[audio_order[i]];
      var audio_id = audio_order[i];

      // create question container
      var question_classes = ['jspsych-survey-mushra-question'];
      if (audio.horizontal) {
        question_classes.push('jspsych-survey-mushra-horizontal');
      }

      html += '<div id="jspsych-survey-mushra-'+audio_id+'" class="'+question_classes.join(' ')+'"  data-name="'+audio.name+'">';

      // add question text: default "ver [i]"
      var pretty_i = i+1
      html += '<p class="jspsych-survey-mushra-text survey-mushra">' + '<b>ver '+pretty_i+'</b>'
      if(audio.required){
        html += "<span class='required'>*</span>";
      }
      html += '</p>';

       // add play and stop buttons
      html += '<input type="button" id="play-btn-here-'+audio_id+'"  class="'+plugin_id_name+' jspsych-btn"' + ' value="play"' + '></input> ';
      html += '<input type="button" id="stop-'+audio_id+'" class="'+plugin_id_name+' jspsych-btn"' + ' value="stop"' + '></input> <br>';

      // create option radio buttons
      for (var j = 0; j < trial.options.length; j++) {
        // add label and question text
        var option_id_name = "jspsych-survey-mushra-option-"+audio_id+"-"+j;
        var input_name = 'jspsych-survey-mushra-response-'+audio_id;
        var input_id = 'jspsych-survey-mushra-response-'+audio_id+'-'+j;

        var required_attr = audio.required ? 'required' : '';

        // add radio button container
        html += '<div id="'+option_id_name+'" class="jspsych-survey-mushra-option">';
        html += '<label class="jspsych-survey-mushra-text" for="'+input_id+'">';
        html += '<input type="radio" name="'+input_name+'" id="'+input_id+'" value="'+trial.options[j]+'" '+required_attr+'></input>';
        html += trial.options[j]+'</label>';
        html += '</div>';
      }

      html += '</div>';
      html += '</div>';
    }
    html += '</div>';

    // show transcripts (if provided)
    html += '<dev>'
    for (var i = 0; i < trial.audios.length; i++) {
      var audio = trial.audios[audio_order[i]];
      var pretty_i = i+1

      if (audio.transcript == '') {
        continue
      }

      html += '<b>ver '+pretty_i+':</b> '
      html += audio.transcript
      html += '<br>'
    }
    if (trial.single_transcript) {
      html += '<b>text:</b> '
      html += trial.single_transcript
      html += '<br>'
    }
    html += '</dev>'
    
    // add submit button
    html += '<input type="submit" id="'+plugin_id_name+'-next-submit" class="'+plugin_id_name+' jspsych-btn"' + (trial.button_label ? ' value="'+trial.button_label + '"': '') + '></input>';
    html += '</form>';

    // render
    display_element.innerHTML = html;

    // audio context and volume
    var audio_player = null
    var context = jsPsych.pluginAPI.audioContext();
    var gainNode = null
    if (context !== null) {
      var gainNode = context.createGain();
      gainNode.gain.value = trial.audio_volume
    }
    var audio_volume = trial.audio_volume // only used in html audio
    var volumeControl = document.querySelector('#audio_volume')
    volumeControl.addEventListener('input', function(){
      if (gainNode !== null) {
        gainNode.gain.value = this.value
      }
      else if (audio_player !== null) {
        audio_player.volume = this.value
        audio_volume = this.value
      }
    })

    var play_buttons = []
    var stop_buttons = []
    var startTime;     // record webaudio context start time
    startTime = performance.now();
    var playing_i = 0
    var finished_playing = true
    for (var i = 0; i < trial.audios.length; i++) {
      // var question_id = question_order[i];
      var x = document.getElementById('play-btn-here-' + i);
      x.addEventListener("click", function (event) {
        // event.preventDefault();
        if (!finished_playing) {
          return
        }

        var model_i = event.target.id.slice(-1)
        // model_i = question_id[model_i]

        // change play button color
        play_buttons[playing_i].style["color"] = "black"
        play_buttons[playing_i].style["background-color"] = "white"
        this.style["color"] = "white"
        this.style["background-color"] = "blue"
        playing_i = model_i

        // window.alert("playing0")
        if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
        }
        // start time
        // jsPsych.pluginAPI.getAudioBuffer(audio_name+model_i+'.wav')
        jsPsych.pluginAPI.getAudioBuffer(trial.audios[model_i].audio_name)
        // jsPsych.pluginAPI.getAudioBuffer('input0_sample0.wav')
            .then(function (buffer) {
              if (context !== null) {
                audio_player = context.createBufferSource();
                audio_player.buffer = buffer;
                audio_player.connect(gainNode)
                gainNode.connect(context.destination)
                // audio_player.connect(context.destination);
              } else {
                audio_player = buffer;
                audio_player.currentTime = 0;
                audio_player.volume = audio_volume
              }

              audio_player.onended = function () {
                play_buttons[playing_i].style["color"] = "black"
                play_buttons[playing_i].style["background-color"] = "white"
                finished_playing = true
              }

              // start audio
              if (context !== null) {
                startTime = context.currentTime;
                audio_player.start(startTime);
              } else {
                audio_player.play();
              }
              finished_playing = false
            })
            .catch(function (err) {
              console.error(`Failed to load audio file. Try checking the file path. We recommend using the preload plugin to load audio files.`)
              console.error(err)
            });
      })
      play_buttons.push(x)

      var x = document.getElementById('stop-'+i);
      x.addEventListener("click", function (event) {
        if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
        }
        play_buttons[playing_i].style["color"] = "black"
        play_buttons[playing_i].style["background-color"] = "white"
        finished_playing = true
      })
      stop_buttons.push(x)
    }

    // var y = document.getElementById("jspsych-survey-mushra-next-submit")
    document.querySelector('form').addEventListener('submit', function(event) {
    // y.addEventListener("click", function(event) {
      event.preventDefault();

      // measure response time
      var endTime = performance.now();
      var response_time = endTime - startTime;

      // create object to hold responses
      var response_data = {};
      for(var i=0; i<trial.audios.length; i++){
        var match = display_element.querySelector('#jspsych-survey-mushra-'+i);
        var id = "audio" + i;
        if(match.querySelector("input[type=radio]:checked") !== null){
          var val = match.querySelector("input[type=radio]:checked").value;
        } else {
          window.alert("must choose all options")
          // return;
          var val = "";
        }
        var obje = {};
        var name = id;
        obje[name] = val;
        Object.assign(response_data, obje);
      }
      // save data
      var trial_data = {
        rt: response_time,
        response: response_data,
        audio_order: audio_order,
        test_name: trial.test_name
      };
      display_element.innerHTML = '';

      // stop audio
      if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
        }

      // change overall volume with this volume
      if (trial.change_overall_volume !== null) {
        if (gainNode !== null) {
          trial.change_overall_volume(gainNode.gain.value)
        }
        else {
          trial.change_overall_volume(audio_volume)
        }
      }

      // next trial
      jsPsych.finishTrial(trial_data);
    });
  };

  return plugin;
})();
