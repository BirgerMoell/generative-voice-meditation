/**
 * jspsych-video-mushra
 * Video Mushra test
 * modified from:
 * jspsych-video-button-response
 * Josh de Leeuw
 *
 * plugin for playing multiple videos and
 *
 *
 * documentation: docs.jspsych.org
 *
 **/

jsPsych.plugins["video-mushra"] = (function() {

  var plugin = {};

  jsPsych.pluginAPI.registerPreload('video-mushra', 'stimulus', 'video');

  plugin.info = {
    name: 'video-mushra',
    description: '',
    parameters: {
      test_name:{
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default: "video-mushra-test",
        description: 'The name of the test, part of the response'
      },
      videos: {
        type: jsPsych.plugins.parameterType.VIDEO,
        pretty_name: 'Videos',
        default: undefined,
        description: 'The video files to play.'
      },
      choices: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Choices',
        default: undefined,
        array: true,
        description: 'The labels for the buttons.'
      },
      questions: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Questions',
        default: undefined,
        array: true,
        description: 'The questions.'
      },
      button_html: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button HTML',
        default: '<button class="jspsych-btn">%choice%</button>',
        array: true,
        description: 'The html of the button. Can create own style.'
      },
      prompt: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Prompt',
        default: null,
        description: 'Any content here will be displayed below the buttons.'
      },
      width: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Width',
        default: '',
        description: 'The width of the video in pixels.'
      },
      height: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Height',
        default: '',
        description: 'The height of the video display in pixels.'
      },
      autoplay: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Autoplay',
        default: true,
        description: 'If true, the video will begin playing as soon as it has loaded.'
      },
      controls: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Controls',
        default: false,
        description: 'If true, the subject will be able to pause the video or move the playback to any point in the video.'
      },
      start: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Start',
        default: null,
        description: 'Time to start the clip.'
      },
      stop: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Stop',
        default: null,
        description: 'Time to stop the clip.'
      },
      rate: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Rate',
        default: 1,
        description: 'The playback rate of the video. 1 is normal, <1 is slower, >1 is faster.'
      },
      trial_ends_after_video: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'End trial after video finishes',
        default: false,
        description: 'If true, the trial will end immediately after the video finishes playing.'
      },
      trial_duration: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Trial duration',
        default: null,
        description: 'How long to show trial before it ends.'
      },
      margin_vertical: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Margin vertical',
        default: '0px',
        description: 'The vertical margin of the button.'
      },
      margin_horizontal: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Margin horizontal',
        default: '8px',
        description: 'The horizontal margin of the button.'
      },
      response_ends_trial: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Response ends trial',
        default: true,
        description: 'If true, the trial will end when subject makes a response.'
      },
      response_allowed_while_playing: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Response allowed while playing',
        default: true,
        description: 'If true, then responses are allowed while the video is playing. '+
          'If false, then the video must finish playing before a response is accepted.'
      },
      randomize: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Randomize the order of videos',
        default: true,
        description: 'If true, then the order of videos is randomized and the order is part of response'
      },
      single_question: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Single question',
        default: true,
        description: 'If true, then the following layout: Videos on top of page, and single question at the bottom'
      }
    }
  }

  plugin.trial = function(display_element, trial) {

    var video_html = ""
    video_html += '<style id="jspsych-survey-mushra-css">';
    video_html +=
        ".jspsych-video-mushra-question { margin-top: 2em; margin-bottom: 2em; text-align: left; }\n"+
        ".jspsych-video-mushra-text {  text-align: left;}\n"+
        ".jspsych-video-mushra-option { line-height: 2; }\n"+
         "  .tri_column {\n" +
        "    float: left;\n" +
        "    width: 33%;\n" +
        "  }\n" +
        "\n" +
         "  .five_column {\n" +
        "    float: left;\n" +
        "    width: 20%;\n" +
        "  }\n" +
        "\n" +
        "  .column {\n" +
        "    float: left;\n" +
        "    width: 50%;\n" +
        "  }\n" +
        "\n" +
        "  /* Clear floats after the columns */\n" +
        "  .row:after {\n" +
        "    content: \"\";\n" +
        "    display: table;\n" +
        "    clear: both;\n" +
        "  }"
    video_html += '</style>'

    // add prompt if there is one
    if (trial.prompt !== null) {
      video_html += trial.prompt;
    }

    video_html += '<form id="jspsych-video-mushra-form" autocomplete="off">';
    // ##setup stimulus

    // randomize videos
    var video_order = []
    for (var i=0;i<trial.videos.length;i++)
    {
      video_order.push(i)
    }
    if (trial.randomize){
      video_order = jsPsych.randomization.shuffle(video_order)
    }

    // var
    video_html += '<div class="row">'
    // video_html += '<div>'
    for (var i=0; i < trial.videos.length; i++){
      video_i = video_order[i]
      var pretty_i = i+1 // display order
      video_html += '<div class="column">'
      video_html+='<p class="jspsych-video-mushra-text video-mushra"> video '+pretty_i+': </p>'
      video_html += '<video id="jspsych-video-mushra-stimulus-'+video_i+'"';

      if(trial.width) {
        video_html += ' width="'+trial.width+'"';
      }
      if(trial.height) {
        video_html += ' height="'+trial.height+'"';
      }
      // if(trial.autoplay & (trial.start == null)){
      //   // if autoplay is true and the start time is specified, then the video will start automatically
      //   // via the play() method, rather than the autoplay attribute, to prevent showing the first frame
      //   video_html += " autoplay ";
      // }
      if(trial.controls){
        video_html +=" controls ";
      }
      // if (trial.start !== null) {
      //   // hide video element when page loads if the start time is specified,
      //   // to prevent the video element from showing the first frame
      //   video_html += ' style="visibility: hidden;"';
      // }
      video_html +=">";

      // var video_preload_blob = jsPsych.pluginAPI.getVideoBuffer(trial.videos[0]);
      // if(!video_preload_blob) {
      //   for(var i=0; i<trial.videos.length; i++){
      var file_name = trial.videos[video_i];
      if(file_name.indexOf('?') > -1){
        file_name = file_name.substring(0, file_name.indexOf('?'));
      }
      var type = file_name.substr(file_name.lastIndexOf('.') + 1);
      type = type.toLowerCase();
      if (type == "mov") {
        console.warn('Warning: video-mushra plugin does not reliably support .mov files.')
      }
      video_html+='<source src="' + file_name + '" type="video/'+type+'">';
        // }
      // }
      video_html += "</video>";

      // add question text: default "ver [i]"
      // video_html += '<p class="jspsych-video-mushra-text video-mushra">' + '<b>video '+pretty_i+'</b>'
      // video_html += '</p>';

      // create option radio buttons
      if (!trial.single_question){
        for (var q_i=0; q_i < trial.questions.length; q_i++){
          video_html += '<div class="tri_column">'
          video_html += '<div id="jspsych-video-mushra-'+video_i+'-q'+q_i+'" class="jspsych-video-mushra-question"  data-name="video-'+video_i+'">';
          video_html += '<p class="jspsych-video-mushra-text video-mushra">' + '<b>'+trial.questions[q_i]+'</b> </p>';
          for (var j = 0; j < trial.choices.length; j++) {
            // add label and question text
            var option_id_name = "jspsych-video-mushra-option-"+video_i+"-q"+q_i+"-"+j;
            var input_name = 'jspsych-video-mushra-response-'+video_i+"-q"+q_i;
            var input_id = 'jspsych-video-mushra-response-'+video_i+"-q"+q_i+'-'+j;

            var required_attr = 'required' //audio.required ? 'required' : '';

            // add radio button container
            video_html += '<div id="'+option_id_name+'" class="jspsych-video-mushra-option">';
            video_html += '<label class="jspsych-video-mushra-text" for="'+input_id+'">';
            video_html += '<input type="radio" name="'+input_name+'" id="'+input_id+'" value="'+trial.choices[j]+'" '+required_attr+'></input>';
            video_html += trial.choices[j]+'</label>';
            video_html += '</div>';
          }
          video_html += '</div>'
          video_html += '</div>'
        }
      }

      video_html += '</div>'
    }
    video_html += "</div>";

    // //display buttons
    // var buttons = [];
    // if (Array.isArray(trial.button_html)) {
    //   if (trial.button_html.length == trial.choices.length) {
    //     buttons = trial.button_html;
    //   } else {
    //     console.error('Error in video-mushra plugin. The length of the button_html array does not equal the length of the choices array');
    //   }
    // } else {
    //   for (var i = 0; i < trial.choices.length; i++) {
    //     buttons.push(trial.button_html);
    //   }
    // }
    // video_html += '<div id="jspsych-video-mushra-btngroup">';
    // for (var i = 0; i < trial.choices.length; i++) {
    //   var str = buttons[i].replace(/%choice%/g, trial.choices[i]);
    //   video_html += '<div class="jspsych-video-mushra-button" style="cursor: pointer; display: inline-block; margin:'+trial.margin_vertical+' '+trial.margin_horizontal+'" id="jspsych-video-mushra-button-' + i +'" data-choice="'+i+'">'+str+'</div>';
    // }
    // video_html += '</div>';

    video_html += '<div class="row">'
    if (trial.single_question) {
      for (var i=0; i < trial.videos.length; i++) {
        video_i = video_order[i]
        var q_i = 0
        var pretty_i = i+1
        video_html += '<div class="five_column">'
        video_html += '<div id="jspsych-video-mushra-' + video_i + '-q' + q_i + '" class="jspsych-video-mushra-question"  data-name="video-' + video_i + '">';
        video_html += '<p class="jspsych-video-mushra-text video-mushra">' + '<b>video ' + pretty_i + ':</b> </p>';
        for (var j = 0; j < trial.choices.length; j++) {
          // add label and question text
          var option_id_name = "jspsych-video-mushra-option-" + video_i + "-q" + q_i + "-" + j;
          var input_name = 'jspsych-video-mushra-response-' + video_i + "-q" + q_i;
          var input_id = 'jspsych-video-mushra-response-' + video_i + "-q" + q_i + '-' + j;

          var required_attr = 'required' //audio.required ? 'required' : '';

          // add radio button container
          video_html += '<div id="' + option_id_name + '" class="jspsych-video-mushra-option">';
          video_html += '<label class="jspsych-video-mushra-text" for="' + input_id + '">';
          video_html += '<input type="radio" name="' + input_name + '" id="' + input_id + '" value="' + trial.choices[j] + '" ' + required_attr + '></input>';
          video_html += trial.choices[j] + '</label>';
          video_html += '</div>';
        }
        video_html += '</div>'
        video_html += '</div>'
      }
    }
    video_html += '</div>'
    // video_html += '<br/> <p></p>'

    // submit button
    video_html += '<input type="submit" id="jspsych-video-mushra-next-submit" class="jspsych-video-mushra jspsych-btn" value="Continue"></input>';

    video_html += '</form>'
    display_element.innerHTML = video_html;
    
    // var start_time = performance.now();
    //
    // var video_element = display_element.querySelector('#jspsych-video-mushra-stimulus-0');
    //
    // if(video_preload_blob){
    //   video_element.src = video_preload_blob;
    // }

    // video_element.onended = function(){
    //   if(trial.trial_ends_after_video){
    //     end_trial();
    //   } else if (!trial.response_allowed_while_playing) {
    //     enable_buttons();
    //   }
    // }

    // video_element.playbackRate = trial.rate;

    // // if video start time is specified, hide the video and set the starting time
    // // before showing and playing, so that the video doesn't automatically show the first frame
    // if(trial.start !== null){
    //   video_element.pause();
    //   video_element.currentTime = trial.start;
    //   video_element.onseeked = function() {
    //     video_element.style.visibility = "visible";
    //     if (trial.autoplay) {
    //       video_element.play();
    //     }
    //   }
    // }
    //
    // if(trial.stop !== null){
    //   video_element.addEventListener('timeupdate', function(e){
    //     var currenttime = video_element.currentTime;
    //     if(currenttime >= trial.stop){
    //       video_element.pause();
    //     }
    //   })
    // }
    //
    // if(trial.response_allowed_while_playing){
    //   enable_buttons();
    // } else {
    //   disable_buttons();
    // }
    //
    // // store response
    // var response = {
    //   rt: null,
    //   button: null
    // };

    // function to end trial when it is time
    function end_trial() {

      // kill any remaining setTimeout handlers
      // jsPsych.pluginAPI.clearAllTimeouts();

      // stop the video file if it is playing
      // remove any remaining end event handlers
      for (var i=0;i<trial.videos.length;i++){
        display_element.querySelector('#jspsych-video-mushra-stimulus-'+i).pause();
        display_element.querySelector('#jspsych-video-mushra-stimulus-'+i).onended = function() {};
      }

      var responses = {}
      for(var i=0; i<trial.videos.length; i++){
        var video_response = {}
        var num_questions = 1
        if (!trial.single_question){
          num_questions = trial.questions.length
        }
        for (var q_i=0;q_i<num_questions;q_i++) {
          var match = display_element.querySelector('#jspsych-video-mushra-' + i + '-q'+q_i);
          if (match.querySelector("input[type=radio]:checked") !== null) {
            var val = match.querySelector("input[type=radio]:checked").value;
          } else {
            window.alert("must choose all options")
            // return;
            var val = "";
          }
          video_response[q_i] = val
        }
        responses[i] = video_response
      }

      // gather the data to store for the trial
      var trial_data = {
        videos: trial.videos,
        response: responses,
        video_order: video_order,
        test_name: trial.test_name
      };

      // clear the display
      display_element.innerHTML = '';

      // move on to the next trial
      jsPsych.finishTrial(trial_data);
    }

    document.querySelector('form').addEventListener('submit', function(event) {
      // y.addEventListener("click", function(event) {
      event.preventDefault();

      end_trial();
    })
    // // function to handle responses by the subject
    // function after_response(choice) {
    //
    //   // measure rt
    //   var end_time = performance.now();
    //   var rt = end_time - start_time;
    //   response.button = parseInt(choice);
    //   response.rt = rt;
    //
    //   // after a valid response, the stimulus will have the CSS class 'responded'
    //   // which can be used to provide visual feedback that a response was recorded
    //   video_element.className += ' responded';
    //
    //   // disable all the buttons after a response
    //   disable_buttons();
    //
    //   if (trial.response_ends_trial) {
    //     end_trial();
    //   }
    // }
    //
    // function button_response(e){
    //   var choice = e.currentTarget.getAttribute('data-choice'); // don't use dataset for jsdom compatibility
    //   after_response(choice);
    // }
    //
    // function disable_buttons() {
    //   var btns = document.querySelectorAll('.jspsych-video-mushra-button');
    //   for (var i=0; i<btns.length; i++) {
    //     var btn_el = btns[i].querySelector('button');
    //     if(btn_el){
    //       btn_el.disabled = true;
    //     }
    //     btns[i].removeEventListener('click', button_response);
    //   }
    // }
    //
    // function enable_buttons() {
    //   var btns = document.querySelectorAll('.jspsych-video-mushra-button');
    //   for (var i=0; i<btns.length; i++) {
    //     var btn_el = btns[i].querySelector('button');
    //     if(btn_el){
    //       btn_el.disabled = false;
    //     }
    //     btns[i].addEventListener('click', button_response);
    //   }
    // }
    //
    // // end trial if time limit is set
    // if (trial.trial_duration !== null) {
    //   jsPsych.pluginAPI.setTimeout(function() {
    //     end_trial();
    //   }, trial.trial_duration);
    // }
  };

  return plugin;
})();
