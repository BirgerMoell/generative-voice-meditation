/**
 * jspsych-video-mushra
 * Video Mushra test
 * modified from:
 * jspsych-video-button-response
 * Josh de Leeuw
 *
 * plugin for playing multiple videos and
 *
 *
 * documentation: docs.jspsych.org
 *
 **/

jsPsych.plugins["video-mushra-single"] = (function() {

  var plugin = {};

  jsPsych.pluginAPI.registerPreload('video-mushra-single', 'stimulus', 'video');

  plugin.info = {
    name: 'video-mushra-single',
    description: '',
    parameters: {
      test_name:{
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default: "video-mushra-single-test",
        description: 'The name of the test, part of the response'
      },
      videos: {
        type: jsPsych.plugins.parameterType.VIDEO,
        pretty_name: 'Videos',
        default: undefined,
        description: 'The video files to play.'
      },
      choices: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Choices',
        default: undefined,
        array: true,
        description: 'The labels for the buttons.'
      },
      button_html: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button HTML',
        default: '<button class="jspsych-btn">%choice%</button>',
        array: true,
        description: 'The html of the button. Can create own style.'
      },
      prompt: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Prompt',
        default: null,
        description: 'Any content here will be displayed below the buttons.'
      },
      width: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Width',
        default: '',
        description: 'The width of the video in pixels.'
      },
      height: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Height',
        default: '',
        description: 'The height of the video display in pixels.'
      },
      randomize: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Randomize the order of videos',
        default: true,
        description: 'If true, then the order of videos is randomized and the order is part of response'
      },
      fade_speed: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Fade speed',
        default: 20,
        description: 'Fade in/out speed: miliseconds to update opacity'
      },
      video_background_color: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Video background color',
        default: "#474747",
        description: 'The background of html video element will be set to this color.'
      },
      audio_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Audio volume',
        default: 0.02,
        description: 'Specify audio playing volume from 0.0 to 1.0'
      },
      max_audio_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Max audio volume',
        default: 0.20,
        description: 'Specify max audio playing volume from 0.0 to 1.0'
      },
      get_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Get overall volume function',
        default: null,
        description: 'function that returns current overall volume for the experiment'
      },
      change_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Change overall volume function',
        default: null,
        description: 'function to change overall volume for subsequent tests'
      }
    }
  }

  plugin.trial = function(display_element, trial) {
    var plugin_id_name = "jspsych-video-mushra";

    var question_column_perc = 70 / trial.videos.length

    var video_html = ""
    video_html += '<style id="jspsych-survey-mushra-css">';
    video_html +=
        ".jspsych-video-mushra-single-question { margin-top: 2em; margin-bottom: 2em; text-align: left; }\n"+
        ".jspsych-video-mushra-single-text {  text-align: left;}\n"+
        ".jspsych-video-mushra-single-option { line-height: 2; }\n"+
         "  .tri_column {\n" +
        "    float: left;\n" +
        "    width: 33%;\n" +
        "  }\n" +
        "\n" +
         "  .five_column {\n" +
        "    float: left;\n" +
        "    width: 20%;\n" +
        "  }\n" +
        "\n" +
        "  .column {\n" +
        "    float: left;\n" +
        "    width: 50%;\n" +
        "  }\n" +
        "\n" +
        "  /* Clear floats after the columns */\n" +
        "  .row:after {\n" +
        "    content: \"\";\n" +
        "    display: table;\n" +
        "    clear: both;\n" +
        "  }"+
        "  .question_column {\n" +
        "    float: left;\n" +
        "    width: "+question_column_perc+"%;\n" +
         "  }\n"
    video_html += '</style>'

    // randomize videos
    var video_order = []
    for (var i=0;i<trial.videos.length;i++)
    {
      video_order.push(i)
    }
    if (trial.randomize){
      video_order = jsPsych.randomization.shuffle(video_order)
    }

    // add prompt if there is one
    if (trial.prompt !== null) {
      video_html += trial.prompt;
    }

    // place video on top
    video_html += '<div id="video_div"><video id="jspsych-video-mushra-single-video"'

    if(trial.width) {
      video_html += ' width="'+trial.width+'"';
    }
    if(trial.height) {
      video_html += ' height="'+trial.height+'"';
    }
    video_html +='>';

    var file_name = trial.videos[video_order[0]];
    if(file_name.indexOf('?') > -1){
      file_name = file_name.substring(0, file_name.indexOf('?'));
    }
    var type = file_name.substr(file_name.lastIndexOf('.') + 1);
    type = type.toLowerCase();
    if (type == "mov") {
      console.warn('Warning: video-mushra-single plugin does not reliably support .mov files.')
    }
    video_html+='<source src="' + file_name + '" type="video/'+type+'">';
    // video_html+='<source src="" type="video/'+type+'">';

    video_html += "</video></div>";

    // volume slider
    video_html += '<label for="audio_volume">Volume</label>'
    video_html += '<input type="range" id="audio_volume" name="audio_volume" min="0" max="'+trial.max_audio_volume+'" step="0.002" value="'+trial.audio_volume+'"></input>'

    video_html += '<form id="jspsych-video-mushra-single-form" autocomplete="off">';

    // columns with video play/stop buttons and corresponding choices
    video_html += '<div class="row">'
    for (var i=0; i < trial.videos.length; i++) {
      video_i = video_order[i]
      var pretty_i = i+1
      video_html += '<div class="question_column">'
      video_html += '<div id="jspsych-video-mushra-single-question-video-' + video_i + '" class="jspsych-video-mushra-single-question"  data-name="video-' + video_i + '">';

      video_html += '<p><b>video '+ pretty_i + '</b></p>'
      video_html += '<input type="button" id="play-btn-here-'+video_i+'"  class="'+plugin_id_name+' jspsych-btn"' + ' value="play"></input> '; //style="font-weight:bold"
      video_html += '<input type="button" id="stop-'+video_i+'" class="'+plugin_id_name+' jspsych-btn"' + ' value="stop"' + '></input> <br>';

      for (var j = 0; j < trial.choices.length; j++) {
        // add label and question text
        var option_id_name = "jspsych-video-mushra-single-option-" + video_i + "-" + j;
        var input_name = 'jspsych-video-mushra-single-response-' + video_i;
        var input_id = 'jspsych-video-mushra-single-response-' + video_i + '-' + j;

        var required_attr = 'required'

        // add radio button container
        video_html += '<div id="' + option_id_name + '" class="jspsych-video-mushra-single-option">';
        video_html += '<label class="jspsych-video-mushra-single-text" for="' + input_id + '">';
        video_html += '<input type="radio" name="' + input_name + '" id="' + input_id + '" value="' + trial.choices[j] + '" ' + required_attr + '></input>';
        video_html += trial.choices[j] + '</label>';
        video_html += '</div>';
      }
      video_html += '</div>'
      video_html += '</div>'
    }
    video_html += '</div>'

    // submit button
    video_html += '<input type="submit" id="jspsych-video-mushra-single-next-submit" class="jspsych-video-mushra-single jspsych-btn" value="Continue"></input>';

    video_html += '</form>'
    display_element.innerHTML = video_html;
    
    // set video element color
    var video_element = display_element.querySelector('#jspsych-video-mushra-single-video');
    video_element.style["background-color"] = trial.video_background_color
    var op = 0.0
    video_element.style["opacity"] = op
    var video_div = display_element.querySelector('#video_div')
    video_div.style["background-color"] = trial.video_background_color
    video_div.style["width"] = trial.width+"px"
    video_div.style["height"] = trial.height+"px"

    // starting volume
    var audio_volume = trial.audio_volume
    if (trial.get_overall_volume !== null) {
      audio_volume = trial.get_overall_volume()
    }
    video_element.volume = audio_volume

    // volume controller
    var volumeControl = document.querySelector('#audio_volume')
    volumeControl.value = audio_volume
    volumeControl.addEventListener('input', function(){
      video_element.volume = this.value
      audio_volume = this.value
    })

    // fade in and fade out funcs
    var is_playing = false
    var is_fading = false
    fade_in = function() {
      timer = setInterval(function() {
          if (op >= 1) {
            op = 1.0
            video_element.style["opacity"] = op
            video_element.play()
            is_playing = true
            is_fading = false
            clearInterval(timer);
          }
          video_element.style["opacity"] = op
          op += 0.05
        }, trial.fade_speed)
    }
    fade_out = function() {
      timer = setInterval(function() {
          if (op <= 0) {
            op = 0.0
            video_element.style["opacity"] = op
            video_element.pause()
            is_playing = false
            is_fading = false
            clearInterval(timer);
          }
          video_element.style["opacity"] = op
          op -= 0.05
        }, trial.fade_speed)
    }

    var play_buttons = []
    var stop_buttons = []
    var playing_i = video_order[0]
    video_element.onended = function(){
      fade_out()
      play_buttons[playing_i].style["color"] = "black"
      play_buttons[playing_i].style["background-color"] = "white"
    }
    for (var i = 0; i < trial.videos.length; i++) {
      // var question_id = question_order[i];
      var x = document.getElementById('play-btn-here-' + i);
      x.addEventListener("click", function (event) {
        // event.preventDefault();
        if (is_playing || is_fading){
          return
        }
        is_fading = true

        var video_i = event.target.id.slice(-1)
        op = 0.0
        video_element.style["opacity"] = op
        video_element.src = trial.videos[video_i]

        fade_in()

        event.target.style["color"] = 'white'
        event.target.style["background-color"] = 'blue'
        playing_i = video_i
      })
      play_buttons.push(x)

      var x = document.getElementById('stop-'+i);
      x.addEventListener("click", function (event) {
        if (is_fading || (!is_playing)) {
          return
        }
        is_fading = true

        var button_i = event.target.id.slice(-1)
        play_buttons[playing_i].style["color"] = "black"
        play_buttons[playing_i].style["background-color"] = "white"

        video_element.pause()
        fade_out()
      })
      stop_buttons.push(x)
    }

    // function to end trial when it is time
    function end_trial() {

      // kill any remaining setTimeout handlers
      // jsPsych.pluginAPI.clearAllTimeouts();

      // stop the video
      video_element.pause()

      var responses = {}
      for(var i=0; i<trial.videos.length; i++){
        var match = display_element.querySelector('#jspsych-video-mushra-single-question-video-' + i);
        if (match.querySelector("input[type=radio]:checked") !== null) {
          var val = match.querySelector("input[type=radio]:checked").value;
        } else {
          window.alert("error: the test can not continue.")
          var val = "";
        }
        responses[i] = val
      }

      // gather the data to store for the trial
      var trial_data = {
        videos: trial.videos,
        response: responses,
        video_order: video_order,
        test_name: trial.test_name
      };

      // clear the display
      display_element.innerHTML = '';

      // set overall volume
      if (trial.change_overall_volume !== null){
        trial.change_overall_volume(audio_volume)
      }

      // move on to the next trial
      jsPsych.finishTrial(trial_data);
    }

    document.querySelector('form').addEventListener('submit', function(event) {
      // y.addEventListener("click", function(event) {
      event.preventDefault();

      end_trial();
    })
  };

  return plugin;
})();
