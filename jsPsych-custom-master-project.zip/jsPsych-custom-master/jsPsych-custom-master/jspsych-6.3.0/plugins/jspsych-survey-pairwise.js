/**
 * jspsych-survey-pairwise
 * a jspsych plugin for multiple choice survey questions
 *
 * Shane Martin
 *
 * documentation: docs.jspsych.org
 *
 */


jsPsych.plugins['survey-pairwise'] = (function() {

  var plugin = {};

  plugin.info = {
    name: 'survey-pairwise',
    description: '',
    parameters: {
      audios: {
        type: jsPsych.plugins.parameterType.COMPLEX,
        array: true,
        pretty_name: 'Audios',
        nested: {
          transcript: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Transcript',
            default: '',
            description: 'The transcript of the audio.'
          },
          audio_name: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Audio Name',
            default: '',
            description: 'Full file name of the audio sample'
          }
        }
      },
      questions: {
        type: jsPsych.plugins.parameterType.COMPLEX,
        array: true,
        pretty_name: 'Questions',
        nested: {
          options: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Options',
            array: true,
            default: ["ver1", "ver2"],
            description: 'The response options to the question. Note that the audios are denoted as "ver[i]".'
          },
          prompt: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Prompt',
            default: 'Which version sounds better?',
            description: 'Prompt for the preference selection question.'
          },
          name: {
            type: jsPsych.plugins.parameterType.STRING,
            pretty_name: 'Question name',
            default: '',
          }
        }
      },
      randomize_audio_order: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Randomize Audio Order',
        default: false,
        description: 'If true, the order of the audios will be randomized. The order of randomization is in returned results.'
      },
      preamble: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Preamble',
        default: null,
        description: 'HTML formatted string to display at the top of the page above all the questions.'
      },
      button_label: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button label',
        default:  'Continue',
        description: 'Label of the button.'
      },
      autocomplete: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Allow autocomplete',
        default: false,
        description: "Setting this to true will enable browser auto-complete or auto-fill for the form."
      },
      test_name: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default:  '',
        description: 'Name of test, will be returned in results.'
      },
      show_transcript: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Show transcript',
        default: false,
        description: 'Show transcripts at the bottom of page.'
      }
    }
  }
  plugin.trial = function(display_element, trial) {
    var context = jsPsych.pluginAPI.audioContext();

    var plugin_id_name = "jspsych-survey-pairwise";

    var html = "";

    // inject CSS for trial
    html += '<style id="jspsych-survey-pairwise-css">';
    html += ".jspsych-survey-pairwise-question { margin-top: 2em; margin-bottom: 2em; text-align: left; }"+
      ".jspsych-survey-pairwise-text span.required {color: darkred;}"+
      ".jspsych-survey-pairwise-horizontal .jspsych-survey-pairwise-text {  text-align: left;}"+
      ".jspsych-survey-pairwise-option { line-height: 2; }"+
      ".jspsych-survey-pairwise-horizontal .jspsych-survey-pairwise-option {  display: inline-block;  margin-left: 1em;  margin-right: 1em;  vertical-align: top;}"+
      "label.jspsych-survey-pairwise-text input[type='radio'] {margin-right: 1em;}";//+
      // "\n" +
      //   "  .column {\n" +
      //   "    float: left;\n" +
      //   "    width: 25%;\n" +
      //   "  }\n" +
      //   "\n" +
      //   "  /* Clear floats after the columns */\n" +
      //   "  .row:after {\n" +
      //   "    content: \"\";\n" +
      //   "    display: table;\n" +
      //   "    clear: both;\n" +
      //   "  }";
    html += '</style>';

    // show preamble text
    // trial.preamble =
    if(trial.preamble !== null){
      html += '<div id="jspsych-survey-pairwise-preamble" class="jspsych-survey-pairwise-preamble">'+trial.preamble+'</div>';
    }

    // form element
    if ( trial.autocomplete ) {
    	html += '<form id="jspsych-survey-pairwise-form">';
    } else {
    	html += '<form id="jspsych-survey-pairwise-form" autocomplete="off">';
    }
    // generate question order. this is randomized here as opposed to randomizing the order of trial.questions
    // so that the data are always associated with the same question regardless of order
    var audio_order = [];
    for(var i=0; i<trial.audios.length; i++){
      audio_order.push(i);
    }
    if(trial.randomize_audio_order){
      audio_order = jsPsych.randomization.shuffle(audio_order);
    }

    // add play buttons
    for (var i = 0; i < trial.audios.length; i++) {
      // get audios based on question_order
      // var audio = trial.questions[audio_order[i]];
      var audio_id = audio_order[i];
      var pretty_i = i+1

      // add play button
      html += '<b>ver ' + pretty_i + '</b>   '
      html += '<input type="button" id="play-btn-here-'+audio_id+'"  class="'+plugin_id_name+' jspsych-btn"' + ' value="play"' + '></input> ';
      html += '<input type="button" id="stop-'+audio_id+'" class="'+plugin_id_name+' jspsych-btn"' + ' value="stop"' + '></input> <br>';
    }

    var question_classes = ['jspsych-survey-pairwise-question'];

    for (var q_i = 0; q_i < trial.questions.length; q_i++) {
      var question = trial.questions[q_i]
      html += '<div id="jspsych-survey-pairwise-question-'+ q_i +'" class="' + question_classes.join(' ') + '"  data-name="' + question.name + '">';

      // add question text
      // var pretty_i = i+1
      html += '<p class="jspsych-survey-pairwise-text survey-pairwise">' + question.prompt
      if (question.required) {
        html += "<span class='required'>*</span>";
      }
      html += '</p>';

      // create option radio buttons
      for (var j = 0; j < question.options.length; j++) {
        var option_id_name = "jspsych-survey-pairwise-option-question-" + q_i + "-" + j;
        var input_name = 'jspsych-survey-pairwise-response-question-' + q_i;
        var input_id = 'jspsych-survey-pairwise-response-question-' + q_i + '-' + j;
        var pretty_j = j + 1

        // var required_attr = question.required ? 'required' : '';
        var required_attr = 'required';

        // add radio button container
        html += '<div id="' + option_id_name + '" class="jspsych-survey-pairwise-option">';
        html += '<label class="jspsych-survey-pairwise-text" for="' + input_id + '">';
        // html += '<input type="radio" name="'+input_name+'" id="'+input_id+'" value="'+question.options[j]+'" '+required_attr+'></input>';
        html += '<input type="radio" name="' + input_name + '" id="' + input_id + '" value=" ' + question.options[j] + '" ' + required_attr + '></input>';
        html += '<b>' + question.options[j] + '</b></label>';
        html += '</div>';
      }
      html += '</div>';
    }

    // show transcripts (if provided)
    if (trial.show_transcript) {
      html += '<dev>'
      for (var i = 0; i < trial.audios.length; i++) {
        var audio = trial.audios[audio_order[i]];
        var pretty_i = i + 1

        if (audio.transcript == '') {
          continue
        }

        html += '<b>ver ' + pretty_i + ':</b> '
        html += audio.transcript
        html += '<br>'
      }
      html += '</dev>'
    }

    // add submit button
    html += '<input type="submit" id="'+plugin_id_name+'-next-submit" class="'+plugin_id_name+' jspsych-btn"' + (trial.button_label ? ' value="'+trial.button_label + '"': '') + '></input>';
    html += '</form>';

    // render
    display_element.innerHTML = html;

    var audio_player=null;
    var startTime;     // record webaudio context start time
    startTime = performance.now();

    var play_buttons = []
    var stop_buttons = []
    for (var i = 0; i < trial.audios.length; i++) {
      var audio_id = audio_order[i];
      var x = document.getElementById('play-btn-here-'+audio_id);
      x.addEventListener("click", function (event) {
        // event.preventDefault();

        var model_i = event.target.id.slice(-1)
        // model_i = question_id[model_i]

        // window.alert("playing0")
        if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
        }
        // start time
        jsPsych.pluginAPI.getAudioBuffer(trial.audios[model_i].audio_name)
            .then(function (buffer) {
              if (context !== null) {
                audio_player = context.createBufferSource();
                audio_player.buffer = buffer;
                audio_player.connect(context.destination);
              } else {
                audio_player = buffer;
                audio_player.currentTime = 0;
              }

              // start audio
              if (context !== null) {
                startTime = context.currentTime;
                audio_player.start(startTime);
              } else {
                audio_player.play();
              }
            })
            .catch(function (err) {
              console.error(`Failed to load audio file. Try checking the file path. We recommend using the preload plugin to load audio files.`)
              console.error(err)
            });
      })
      play_buttons.push(x)

      var x = document.getElementById('stop-'+audio_id);
      x.addEventListener("click", function (event) {
        if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
        }
      })
      stop_buttons.push(x)
    }


    // var y = document.getElementById("jspsych-survey-pairwise-next-submit")
    document.querySelector('form').addEventListener('submit', function(event) {
    // y.addEventListener("click", function(event) {
      event.preventDefault();

      // measure response time
      var endTime = performance.now();
      var response_time = endTime - startTime;

      // create object to hold responses
      var question_data = {};
      for(var i=0; i<trial.questions.length; i++) {
        var match = display_element.querySelector('#jspsych-survey-pairwise-question-'+i)
        // var id = "Q" + i;
        if (match.querySelector("input[type=radio]:checked") !== null) {
          var val = match.querySelector("input[type=radio]:checked").value;
        } else {
          window.alert("must choose all options")
          // return;
          var val = "";
        }
        var name = 'Q'+i
        question_data[name] = val;
      }

      // Object.assign(question_data, obje);
      var audio_names = []
      for (var i=0; i<trial.audios.length; i++) {
        audio_names.push(trial.audios[i].audio_name)
      }

      // save data
      var trial_data = {
        rt: response_time,
        response: question_data,
        audio_order: audio_order,
        test_name: trial.test_name,
        audio_names: audio_names
      };
      display_element.innerHTML = '';

      // stop audio
      if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
      }

      // next trial
      jsPsych.finishTrial(trial_data);
    });

    var startTime = performance.now();
  };

  return plugin;
})();
