/**
 *
 * jspsych-survey-single-audio
 * single audio, multiple questions listening test jspsych plugin
 *
 * adapted from jspsych-survey-mushra
 *
 */


jsPsych.plugins['survey-single-audio'] = (function() {

  var plugin = {};

  plugin.info = {
    name: 'survey-single-audio',
    description: '',
    parameters: {
      audio: {
        type: jsPsych.plugins.parameterType.COMPLEX,
        pretty_name: 'Audio',
        transcript: {
          type: jsPsych.plugins.parameterType.STRING,
          pretty_name: 'Transcript',
          default: '',
          description: 'The transcripts will be placed in rows together at the bottom of the page.'
        },
        required: {
          type: jsPsych.plugins.parameterType.BOOL,
          pretty_name: 'Required',
          default: true,
          description: 'Subject will be required to give a rating for this audio. default:true.'
        },
        audio_name: {
          type: jsPsych.plugins.parameterType.STRING,
          pretty_name: 'Audio Name',
          default: '',
          description: 'Full audio file name that is in the same directory as exp html file.'
        }
      },
      questions: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Questions',
        array: true,
        default: [],
        description: 'Questions.'
      },
      options: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Options',
        array: true,
        default: ["5", "4", "3", "2", "1"],
        description: 'Same options for all questions'
      },
      preamble: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Preamble',
        default: null,
        description: 'HTML formatted string to display at the top of the page above all the questions.'
      },
      button_label: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button label',
        default:  'Continue',
        description: 'Label of the continue button.'
      },
      autocomplete: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Allow autocomplete',
        default: false,
        description: "Setting this to true will enable browser auto-complete or auto-fill for the form."
      },
      all_questions_required: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'All questions required',
        default: true,
        description: "Setting this to true if all questions are required."
      },
      test_name: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default:  '',
        description: 'Name of test. Will be recorded as part of results.'
      },
    }
  }
  plugin.trial = function(display_element, trial) {

    var plugin_id_name = "jspsych-survey-single-audio";

    var html = "";

    // inject CSS for trial
    html += '<style id="jspsych-survey-single-audio-css">';
    html += ".jspsych-survey-single-audio-question { margin-top: 2em; margin-bottom: 2em; text-align: left; }"+
      ".jspsych-survey-single-audio-text span.required {color: darkred;}"+
      ".jspsych-survey-single-audio-horizontal .jspsych-survey-single-audio-text {  text-align: center;}"+
      ".jspsych-survey-single-audio-option { line-height: 2; }"+
      ".jspsych-survey-single-audio-horizontal .jspsych-survey-single-audio-option {  display: inline-block;  margin-left: 1em;  margin-right: 1em;  vertical-align: top;}"+
      "label.jspsych-survey-single-audio-text input[type='radio'] {margin-right: 1em;}" +
      '#question_table tr:nth-child(even) {' +
      'background-color: #eee;' +
    '}';
    html += '</style>';

    // show preamble text
    // trial.preamble =
    if(trial.preamble !== null){
      html += '<div id="jspsych-survey-single-audio-preamble" class="jspsych-survey-single-audio-preamble">'+trial.preamble+'</div>';
    }

    // form element
    if ( trial.autocomplete ) {
    	html += '<form id="jspsych-survey-single-audio-form">';
    } else {
    	html += '<form id="jspsych-survey-single-audio-form" autocomplete="off">';
    }

    // add play and stop buttons
    html += '<b> audio: </b>'
    html += '<input type="button" id="play-btn-here'+'"  class="'+plugin_id_name+' jspsych-btn"' + ' value="play"' + '></input> ';
    html += '<input type="button" id="stop-play-btn'+'" class="'+plugin_id_name+' jspsych-btn"' + ' value="stop"' + '></input> <br>';

    // html += '<div class="row">'
    html += '<table id="question_table">'
    html += '<tr>'
    html += '<th></th>' // empty top left cell of the question table
    for (var i=0; i < trial.options.length; i++){
      html += '<th>' + trial.options[i] + '</th>'
    }
    html += '</tr>'
    for (var i = 0; i < trial.questions.length; i++){
      var question_id = i
      html += '<tr id="jspsych-survey-single-audio-question-'+question_id+'">'
      html += '<td>' + trial.questions[question_id] + '</td>'

      // html += '<div id="jspsych-survey-single-audio-question-'+question_id+'">'

      for (var j = 0; j < trial.options.length; j++) {
        // add label and question text
        var option_id_name = "jspsych-survey-single-audio-option-"+question_id+"-"+j;
        var input_name = 'jspsych-survey-single-audio-response-'+question_id;
        var input_id = 'jspsych-survey-single-audio-response-'+question_id+'-'+j;

        var required_attr = trial.all_questions_required ? 'required' : ''

        // add radio button container
        html += '<td>'
        html += '<div id="'+option_id_name+'" class="jspsych-survey-single-audio-option">';
        html += '<label class="jspsych-survey-single-audio-text" for="'+input_id+'">';
        html += '<input type="radio" name="'+input_name+'" id="'+input_id+'" value="'+trial.options[j]+'" '+required_attr+'></input>';
        html += '</label>'; //trial.options[j]+'</label>';
        html += '</div>';
        html += '</td>'
      }
      // html += '</div>'

      html += '</tr>'
    }
    html += '</table>'

    // show transcript (if provided)
    html += '<dev>'
    if (trial.audio.transcript != '') {
      html += '<b>transcript: </b> '
      html += trial.audio.transcript
      html += '<br>'
    }
    html += '</dev>'
    
    // add submit button
    html += '<input type="submit" id="'+plugin_id_name+'-next-submit" class="'+plugin_id_name+' jspsych-btn"' + (trial.button_label ? ' value="'+trial.button_label + '"': '') + '></input>';
    html += '</form>';

    // render
    display_element.innerHTML = html;

    var context = jsPsych.pluginAPI.audioContext();
    var audio_player;
    var startTime;     // record webaudio context start time
    startTime = performance.now();
    var play_button = document.getElementById('play-btn-here');
    play_button.addEventListener("click", function (event) {
      if (audio_player != null) {
        if (context !== null) {
          audio_player.stop();
        } else {
          audio_player.pause();
        }
      }
      // start time
      // jsPsych.pluginAPI.getAudioBuffer(audio_name+model_i+'.wav')
      jsPsych.pluginAPI.getAudioBuffer(trial.audio.audio_name)
      // jsPsych.pluginAPI.getAudioBuffer('input0_sample0.wav')
          .then(function (buffer) {
            if (context !== null) {
              audio_player = context.createBufferSource();
              audio_player.buffer = buffer;
              audio_player.connect(context.destination);
            } else {
              audio_player = buffer;
              audio_player.currentTime = 0;
            }

            // start audio
            if (context !== null) {
              startTime = context.currentTime;
              audio_player.start(startTime);
            } else {
              audio_player.play();
            }
          })
          .catch(function (err) {
            console.error(`Failed to load audio file. Try checking the file path. We recommend using the preload plugin to load audio files.`)
            console.error(err)
          });
    })

    var stop_button = document.getElementById('stop-play-btn');
    stop_button.addEventListener("click", function (event) {
      if (audio_player != null) {
        if (context !== null) {
          audio_player.stop();
        } else {
          audio_player.pause();
        }
      }
    })

    document.querySelector('form').addEventListener('submit', function(event) {
      event.preventDefault();

      // measure response time
      var endTime = performance.now();
      var response_time = endTime - startTime;

      // create object to hold responses
      var response_data = {};
      for(var i=0; i<trial.questions.length; i++){
        var match = display_element.querySelector('#jspsych-survey-single-audio-question-'+i);
        var id = "q" + i;
        if(match.querySelector("input[type=radio]:checked") !== null){
          var val = match.querySelector("input[type=radio]:checked").value;
        } else {
          window.alert("must choose all options")
          // return;
          var val = "";
        }
        response_data[id] = val;
        // document.write("id: "+ id+" val:" + val) // debug only
      }

      // save data
      var trial_data = {
        rt: response_time,
        response: response_data,
        test_name: trial.test_name
      };
      display_element.innerHTML = '';

      // stop audio
      if (audio_player != null) {
          if (context !== null) {
            audio_player.stop();
          } else {
            audio_player.pause();
          }
        }

      // next trial
      jsPsych.finishTrial(trial_data);
    });
  };

  return plugin;
})();
