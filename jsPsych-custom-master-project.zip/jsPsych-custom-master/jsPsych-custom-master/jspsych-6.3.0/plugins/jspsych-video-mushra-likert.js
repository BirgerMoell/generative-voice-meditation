/**
 * jspsych-video-mushra
 * video Mushra test
 * modified from:
 * jspsych-video-button-response
 * Josh de Leeuw
 *
 * plugin for playing multiple videos and
 *
 *
 * documentation: docs.jspsych.org
 *
 **/

 jsPsych.plugins["video-mushra-likert"] = (function() {

  var plugin = {};

  jsPsych.pluginAPI.registerPreload('video-mushra-likert', 'stimulus', 'video');

  plugin.info = {
    name: 'video-mushra-likert',
    description: '',
    parameters: {
      test_name:{
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Test name',
        default: "video-mushra-likert-test",
        description: 'The name of the test, part of the response'
      },
      videos: {
        type: jsPsych.plugins.parameterType.video,
        pretty_name: 'videos',
        default: undefined,
        description: 'The video files to play.'
      },
      choices: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Choices',
        default: undefined,
        array: true,
        description: 'The labels for the buttons.'
      },
      button_html: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Button HTML',
        default: '<button class="jspsych-btn">%choice%</button>',
        array: true,
        description: 'The html of the button. Can create own style.'
      },
      prompt: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Prompt',
        default: null,
        description: 'Any content here will be displayed below the buttons.'
      },
      width: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Width',
        default: '',
        description: 'The width of the video in pixels.'
      },
      height: {
        type: jsPsych.plugins.parameterType.INT,
        pretty_name: 'Height',
        default: '',
        description: 'The height of the video display in pixels.'
      },
      randomize: {
        type: jsPsych.plugins.parameterType.BOOL,
        pretty_name: 'Randomize the order of videos',
        default: true,
        description: 'If true, then the order of videos is randomized and the order is part of response'
      },
      // fade_speed: {
      //   type: jsPsych.plugins.parameterType.FLOAT,
      //   pretty_name: 'Fade speed',
      //   default: 20,
      //   description: 'Fade in/out speed: miliseconds to update opacity'
      // },
      // video_background_color: {
      //   type: jsPsych.plugins.parameterType.STRING,
      //   pretty_name: 'video background color',
      //   default: "#474747",
      //   description: 'The background of html video element will be set to this color.'
      // },
      video_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'video volume',
        default: 0.02,
        description: 'Specify video playing volume from 0.0 to 1.0'
      },
      max_video_volume: {
        type: jsPsych.plugins.parameterType.FLOAT,
        pretty_name: 'Max video volume',
        default: 0.20,
        description: 'Specify max video playing volume from 0.0 to 1.0'
      },
      get_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Get overall volume function',
        default: null,
        description: 'function that returns current overall volume for the experiment'
      },
      change_overall_volume: {
        type: jsPsych.plugins.parameterType.FUNCTION,
        pretty_name: 'Change overall volume function',
        default: null,
        description: 'function to change overall volume for subsequent tests'
      },
      textbox_prompts: {
        type: jsPsych.plugins.parameterType.STRING,
        pretty_name: 'Text box Prompts',
        default: [],
        description: 'Prompt to textbox input'
      },
    }
  }

  plugin.trial = function(display_element, trial) {
    var plugin_id_name = "jspsych-video-mushra";

    var question_column_perc = 100 / trial.videos.length

    var video_html = ""
    video_html += '<style id="jspsych-survey-mushra-css">';
    video_html +=
        ".jspsych-video-mushra-likert-question {font-size: 12px; margin-top: 2em; margin-bottom: 4em; margin-right: 2em; text-align: left; }\n"+
        ".jspsych-video-mushra-likert-question-small-margin {font-size: 12px; margin-top: 0em; margin-bottom: 1em; margin-right: 2em; text-align: left; }\n"+
        ".jspsych-video-mushra-likert-text-left { font-size: 12px; text-align: left; width: 100px;}\n"+
        ".jspsych-video-mushra-likert-text-right { font-size: 12px; text-align: right; width: 100px;}\n"+
        ".jspsych-video-mushra-likert-option { line-height: 2;}\n"+
        ".video_div { align-items: left}"+
        ".make-row {line-height: 2; display: inline-flex; align-items: center; justify-content: flex-start;}\n"+
        ".question {white-space: nowrap;}\n"+
        ".dotrow {white-space: nowrap;}\n"+
        ".textbox {padding-bottom: 20px;}\n"+
        ".buttongroup {display: flex; justify-content: center;}\n"+
        ".text-box {width: -webkit-fill-available; height: 80px;}\n"+
        ".banner {display: flex; justify-content: space-between;}\n"+
        ".play-pause-group {}\n"+

         "  .tri_column {\n" +
        "    float: left;\n" +
        "    width: 33%;\n" +
        "  }\n" +
        "\n" +
         "  .five_column {\n" +
        "    float: left;\n" +
        "    width: 100%;\n" +
        "  }\n" +
        "\n" +
        "  .column {\n" +
        "    float: left;\n" +
        "    width: 50%;\n" +
        "  }\n" +
        "\n" +
        "  /* Clear floats after the columns */\n" +
        "  .row:after {\n" +
        "    content: \"\";\n" +
        "    display: table;\n" +
        "    clear: both;\n" +
        "  }"+
        "  .question_column {\n" +
        "    float: left;\n" +
        "    width: "+question_column_perc+"%;\n" +
        "    display: grid;\n"+
        "    grid-template-rows: auto auto auto;\n"+
        "    justify-items: left;\n"+
         "  }\n"        
         "\n" 
    video_html += '</style>'

    // randomize videos
    var video_order = []
    for (var i=0;i<trial.videos.length;i++)
    {
      video_order.push(i)
    }
    if (trial.randomize){
      video_order = jsPsych.randomization.shuffle(video_order)
    }
    video_html += '<div class= banner>'
    // add prompt if there is one
    if (trial.prompt !== null) {
      video_html += '<h2>' + trial.prompt + '</h2>';
    }

    // // place video on top
    // video_html += '<div id="video_div"><video id="jspsych-video-mushra-likert-video"'

    // if(trial.width) {
    //   video_html += ' width="'+trial.width+'"';
    // }
    // if(trial.height) {
    //   video_html += ' height="'+trial.height+'"';
    // }
    // video_html +='>';

    // var file_name = trial.videos[video_order[0]];
    // if(file_name.indexOf('?') > -1){
    //   file_name = file_name.substring(0, file_name.indexOf('?'));
    // }
    // var type = file_name.substr(file_name.lastIndexOf('.') + 1);
    // type = type.toLowerCase();
    // if (type == "mov") {
    //   console.warn('Warning: video-mushra-likert plugin does not reliably support .mov files.')
    // }
    // video_html+='<source src="' + file_name + '" type="video/'+type+'">';
    // // video_html+='<source src="" type="video/'+type+'">';

    // video_html += "</video></div>";

    // volume slider
    video_html += '<div class= volume-slider> <label for="video_volume">Volume</label>'
    video_html += '<input type="range" id="video_volume" name="video_volume" min="0" max="'+trial.max_video_volume+'" step="0.002" value="'+trial.video_volume+'"></input></div>'
    //banner ending and form beginning
    video_html += '</div>'
    video_html += '</div>'
    video_html += '<form id="jspsych-video-mushra-likert-form" autocomplete="off" style = "padding-bottom: 20px;">';

    // starting volume
    var video_volume = trial.video_volume
    if (trial.get_overall_volume !== null) {
      video_volume = trial.get_overall_volume()
    }

    // columns with video play/stop buttons and corresponding choices
    video_html += '<div class="row">'
    for (var i=0; i < trial.videos.length; i++) {
      
      video_i = video_order[i]
      var pretty_i = i+1
      video_html += '<div class="question_column">'

      // video element
      video_html += '<div class="video_div" id="video_div'+i+'"><video id="jspsych-video-mushra-likert-video-player-' + i + '"'

      if(trial.width) {
        video_html += ' width="'+trial.width+'"';
      }
      if(trial.height) {
        video_html += ' height="'+trial.height+'"';
      }
      // video_html += ' controls '
      video_html += ' volume='+ video_volume
      video_html +='>';

      var file_name = trial.videos[video_i];
      if(file_name.indexOf('?') > -1){
        file_name = file_name.substring(0, file_name.indexOf('?'));
      }
      // var type = file_name.substr(file_name.lastIndexOf('.') + 1);
      // type = type.toLowerCase();
      // if (type == "mov") {
      //   console.warn('Warning: video-mushra-likert plugin does not reliably support .mov files.')
      // }
      type = 'mp4'
      video_html+='<source src="' + file_name + '" type="video/'+type+'">';
      // video_html+='<source src="" type="video/'+type+'">';

      video_html += "</video></div>";


      video_html += '<div id="jspsych-video-mushra-likert-video-' + video_i + '" class="jspsych-video-mushra-likert-question"  data-name="video-' + video_i + '">';

      // video_html += '<p style="text-align: center"><b>video '+ pretty_i + '</b></p>'
      video_html += '<div class=play-pause-group><p><b>video '+ pretty_i + '</b></p>'

      // video_html += '<div class=buttongroup>'
      video_html += '<input type="button" id="play-btn-here-'+i+'"  class="'+plugin_id_name+' jspsych-btn"' + ' value="play"></input> '; //style="font-weight:bold"
      video_html += '<input type="button" id="stop-'+i+'" class="'+plugin_id_name+' jspsych-btn"' + ' value="stop"' + '></input></div>';
      // video_html += '</div>'
      
      for (var j = 0; j < trial.choices.length; j++) {
        // add label and question text
        var question_id_name = "jspsych-video-mushra-likert-question-" + video_i + "-" + j;
        var required_attr = 'required'
        // add radio button container
        video_html += '<div id="' + question_id_name + '" class="jspsych-video-mushra-likert-question">';
        if (i == 0){
          video_html += '<div class= "question">' + trial.choices[j][0] + '</div>'
        } else {
          video_html += '<br>'
        }
        video_html += '<div class="make-row">'
        video_html += '<div class= "jspsych-video-mushra-likert-text-left">' + trial.choices[j][1] + '</div>'
        video_html += '<div class="dotrow">'
        for (var k=0; k < 11; k++) {
          var input_name = 'jspsych-video-mushra-likert-response-' + video_i+ '-' + j// + '-' + k;
          video_html += '<input type="radio" name="' + input_name + '" id="response-' + video_i + '-' + j + '-' + k + '" value="' + k + '" ' + required_attr + '></input>';
        }
        video_html += '</div>'
        video_html += '<div class= "jspsych-video-mushra-likert-text-right">' + trial.choices[j][2] + '</div>'
        video_html += '</div>';
        video_html += '</div>';
      }
      video_html += '</div>'
      video_html += '</div>'
    }
    video_html += '</div>'

    //video_html += '<br></br>'

    for (var i=0; i < trial.textbox_prompts.length; i++)
    {
      video_html += '<div id=text_box'+i+' class=textbox>'
      video_html += '<p class="jspsych-video-mushra-likert-question-small-margin">' + trial.textbox_prompts[i] + '</p>';
      video_html += '<textarea class=text-box id=text_box_input'+i+' type="text" required></textarea>' // style = "width: -webkit-fill-available;" 

      video_html += '</div>'

      if (i == 0)
      {
        // ask favorite
        video_html += '<div id="jspsych-video-mushra-likert-favorite" class="jspsych-video-mushra-likert-question-small-margin"  data-name="all">';
        video_html += '<div class= "question"> Which one is your favorite? </div>'
        video_html += '<div class="dotrow">'
        for (var k=0; k < 3; k++) {
          var input_name = 'jspsych-video-mushra-likert-response-ranking-fav' // + '-' + k;
          video_html += '<input type="radio" name="' + input_name + '" id="response-' + k + '" value="' + k + '" ' + required_attr + '> <b> video ' + (k+1) + ' </b> </input>';
        }
        video_html += '</div>'
        video_html += '</div>'

        // ask least favorite
        video_html += '<div id="jspsych-video-mushra-likert-least-fav" class="jspsych-video-mushra-likert-question-small-margin"  data-name="all">';
        video_html += '<div class= "question"> Which one is your least favorite? </div>'
        video_html += '<div class="dotrow">'
        for (var k=0; k < 3; k++) {
          var input_name = 'jspsych-video-mushra-likert-response-ranking-least-fav' // + '-' + k;
          video_html += '<input type="radio" name="' + input_name + '" id="response-' + k + '" value="' + k + '" ' + required_attr + '> <b> video ' + (k+1) + ' </b> </input>';
        }
        video_html += '</div>'
        video_html += '</div>'
      }
    }

    // submit button
    video_html += '<input type="submit" id="jspsych-video-mushra-likert-next-submit" class="jspsych-video-mushra-likert jspsych-btn" value="Continue"></input>';

    video_html += '</form>'
    display_element.innerHTML = video_html;
    
    // // set video element color
    // var video_element = display_element.querySelector('#jspsych-video-mushra-likert-video');
    // video_element.style["background-color"] = trial.video_background_color
    // var op = 0.0
    // video_element.style["opacity"] = op
    // var video_div = display_element.querySelector('#video_div')
    // video_div.style["background-color"] = trial.video_background_color
    // video_div.style["width"] = trial.width+"px"
    // video_div.style["height"] = trial.height+"px"

    // // starting volume
    // var video_volume = trial.video_volume
    // if (trial.get_overall_volume !== null) {
    //   video_volume = trial.get_overall_volume()
    // }
    // video_element.volume = video_volume

    // fade in and fade out funcs
    // var is_playing = false
    // var is_fading = false
    // fade_in = function() {
    //   timer = setInterval(function() {
    //       if (op >= 1) {
    //         op = 1.0
    //         video_element.style["opacity"] = op
    //         video_element.play()
    //         is_playing = true
    //         is_fading = false
    //         clearInterval(timer);
    //       }
    //       video_element.style["opacity"] = op
    //       op += 0.05
    //     }, trial.fade_speed)
    // }
    // fade_out = function() {
    //   timer = setInterval(function() {
    //       if (op <= 0) {
    //         op = 0.0
    //         video_element.style["opacity"] = op
    //         video_element.pause()
    //         is_playing = false
    //         is_fading = false
    //         clearInterval(timer);
    //       }
    //       video_element.style["opacity"] = op
    //       op -= 0.05
    //     }, trial.fade_speed)
    // }

    var play_buttons = []
    var stop_buttons = []
    var video_elements = []
    var is_playing = false
    var play_count = []
    for (var i = 0; i < trial.videos.length; i++) {
      play_count.push(0)
    }
    for (var i = 0; i < trial.videos.length; i++) {
      var video_element = display_element.querySelector('#jspsych-video-mushra-likert-video-player-'+i);
      video_elements.push(video_element)
      var x = document.getElementById('play-btn-here-' + i);
      x.addEventListener("click", function (event) {
        // event.preventDefault();
        if (is_playing){
          return
        }

        var video_i = event.target.id.slice(-1)
        // op = 0.0
        // video_element.style["opacity"] = op
        // video_element.src = trial.videos[video_i]

        // fade_in()
        video_elements[video_i].volume = video_volume
        video_elements[video_i].play()
        is_playing = true

        event.target.style["color"] = 'white'
        event.target.style["background-color"] = 'blue'
        play_count[video_i] += 1
      })
      play_buttons.push(x)

      var x = document.getElementById('stop-'+i);
      x.addEventListener("click", function (event) {
        if (!is_playing) {
          return
        }

        var button_i = event.target.id.slice(-1)
        play_buttons[button_i].style["color"] = "black"
        play_buttons[button_i].style["background-color"] = "white"

        video_elements[button_i].pause()
        video_elements[button_i].currentTime = 0.0
        is_playing = false
      })
      stop_buttons.push(x)

      video_element.onended = function(event){
        var button_i = event.target.id.slice(-1)
        play_buttons[button_i].style["color"] = "black"
        play_buttons[button_i].style["background-color"] = "white"
        is_playing = false
      }
    }

    // volume controller listener
    var volumeControl = document.querySelector('#video_volume')
    volumeControl.value = video_volume
    volumeControl.addEventListener('input', function(){
      for (var i = 0; i < trial.videos.length; i++)
      {
        video_elements[i].volume = this.value
      }
      video_volume = this.value
    })

    // function to end trial when it is time
    function end_trial() {

      // kill any remaining setTimeout handlers
      // jsPsych.pluginAPI.clearAllTimeouts();

      // stop the video
      video_element.pause()

      var responses = {}

      // get multiple choice preference response
      for(var i=0; i<trial.videos.length; i++){
        video_i = video_order[i]
        for (var j = 0; j < trial.choices.length; j++) {
          var question_id_name = "jspsych-video-mushra-likert-question-" + video_i + "-" + j;

          var match = display_element.querySelector('#' + question_id_name);
          if (match.querySelector("input[type=radio]:checked") !== null) {
            var val = match.querySelector("input[type=radio]:checked").value;
          } else {
            window.alert("error: the test can not continue.")
            var val = "";
          }
          responses[''+video_i+'-'+j] = val
        }
      }
      
      // get textbox response
      for(var i=0; i<trial.textbox_prompts.length; i++){
        var textbox_id = "text_box_input" + i;

        var match = display_element.querySelector('#' + textbox_id);
        var val = match.value;

        responses['text_box'+i] = val
        responses['text_box_prompt'+i] = trial.textbox_prompts[i]      
      }

      // get response on 'favorite' question
      var question_id_name = "jspsych-video-mushra-likert-favorite";
      var match = display_element.querySelector('#' + question_id_name);
      var val = "";
      if (match.querySelector("input[type=radio]:checked") !== null) {
        val = match.querySelector("input[type=radio]:checked").value;
      } else {
        window.alert("error: the test can not continue.")
      }
      responses['favorite'] = video_order[val]

      // get response on 'least favorite' question
      var question_id_name = "jspsych-video-mushra-likert-least-fav";
      var match = display_element.querySelector('#' + question_id_name);
      var val = "";
      if (match.querySelector("input[type=radio]:checked") !== null) {
        val = match.querySelector("input[type=radio]:checked").value;
      } else {
        window.alert("error: the test can not continue.")
      }
      responses['least_favorite'] = video_order[val]
      responses['play_count'] = play_count

      // gather the data to store for the trial
      var trial_data = {
        videos: trial.videos,
        response: responses,
        video_order: video_order,
        test_name: trial.test_name
      };

      // clear the display
      display_element.innerHTML = '';

      // set overall volume
      if (trial.change_overall_volume !== null){
        trial.change_overall_volume(video_volume)
      }

      // move on to the next trial
      jsPsych.finishTrial(trial_data);
    }

    document.querySelector('form').addEventListener('submit', function(event) {
      // y.addEventListener("click", function(event) {
      event.preventDefault();

      end_trial();
    })
  };

  return plugin;
})();
