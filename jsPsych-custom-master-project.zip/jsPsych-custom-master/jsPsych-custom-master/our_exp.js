var timeline = [];

var page_1_options = ["5: good", "4: ok", "3: not good", "2: bad", "1: terrible"];

var multi_choice_block = {
  type: 'survey-multi-choice',
  questions: [
    {prompt: "I like vegetables", name: 'Vegetables', options: page_1_options, required:true},
    {prompt: "I like vegetables 2", name: 'Vegetables', options: page_1_options, required:true},
    {prompt: "I like vegetables 2", name: 'Vegetables', options: page_1_options, required:true},
  ],
};
timeline.push(multi_choice_block)
var multi_choice_block = {
  type: 'survey-multi-choice',
  questions: [
    {prompt: "TEST", name: 'TEST', options: page_1_options, required:true},
      {prompt: "TEST", name: 'TEST', options: page_1_options, required:true},

  ],
};
    timeline.push(multi_choice_block)

jsPsych.init({
  timeline: timeline
});