# Modifications made to original jspsych-6.3.0 repo:
- css/jspsych.css is modified to enlarge the content showing area within a page.
- Original jspsych-survey-multi-choice.js is modified to the first version of Mushra test.
   The script is then copied over to a new jspysch-survey-mushra.js as a standalone script with further improvements to
   Mushra-specific utilities and make the code more readable.
- A jspsych-survey-pairwise.js is added to plugins. This is a binary preference choice test.
- A jspsych-video-mushra.js is added to plugins. This is a Mushra-like test for videos.

# Test locally:
exp.html

# How to use on cognition.run:
1. Add a new task, then go to source code section, choose jsPsych library version: 6.3.0
2. **ONLY** upload these files from this repository to "External JS/CSS": 
   - jspsych-6.3.0/css/jspsych.css
   - jspsych-6.3.0/plugins/jspsych-survey-mushra.js (if being used)
   - jspsych-6.3.0/plugins/jspysch-survey-pairwise.js (if being used)
   - jspsych-6.3.0/plugins/jspsych-video-mushra.js (if being used)

# How to write multiple tests in a .js script and use it in "Task Code" section:
1. Say you have 10 survey-mushra blocks in the first part of the test. They can be put in a function that takes in
   timeline array as a variable:
```javascript
   function test0(timeline) {
      var mushra_page_0 = ...
      timeline.push(mushra_page_0)

      ...

      return timeline
   }
```
2. Upload this file to "External JS/CSS" section.
3. In "Task Code", directly call this function:
```javascript
   var timeline = []
   timeline = test0(timeline)
   ...
```

# Disclaimer:
The scripts here have been tested, but come with no guarantee. It is advised to do internal test runs to ensure e.g. media plays correclty (on different browsers), reponses are recorded correclty, before putting tests out on public platforms.
