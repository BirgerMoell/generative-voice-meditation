function test01(timeline) {
   var pair_choice_block_0 = {
      type: 'survey-pairwise',
      test_name: 'test1_pair',
      audios: [
         {transcript: "sample01 transcript", audio_name: 'stim01.wav'},
         {transcript: "sample02 transcript", audio_name: 'stim02.wav'},
      ],
      questions: [
         {prompt: 'Which version is best?', name: 'preference', options:["ver 1", "ver 2"], required: true},
         {prompt: 'Which version is more entertaining?', name: 'entertain', options:["ver 1", "ver 2", "neither"], required: true},
      ],
      randomize_audio_order: true,
      randomize_question_order: false,
      show_transcript: true
   };
   timeline.push(pair_choice_block_0)
   var pair_choice_block_1 = {
      type: 'survey-pairwise',
      test_name: 'test2_pair',
      audios: [
         {transcript: "sample03 transcript", audio_name: 'stim03.wav'},
         {transcript: "sample04 transcript", audio_name: 'stim04.wav'},
      ],
      questions: [
         {prompt: 'Which version is best?', name: 'preference', options:["ver 1", "ver 2"], required: true},
         {prompt: 'Which version is more entertaining?', name: 'entertain', options:["ver 1", "ver 2", "neither"], required: true},
      ],
      randomize_audio_order: true,
      randomize_question_order: false,
      show_transcript: true
   };
   timeline.push(pair_choice_block_1)
   var pair_choice_block_2 = {
      type: 'survey-pairwise',
      test_name: 'test3_pair',
      audios: [
         {transcript: "sample05 transcript", audio_name: 'stim05.wav'},
         {transcript: "sample06 transcript", audio_name: 'stim06.wav'},
      ],
      questions: [
         {prompt: 'Which version is best?', name: 'preference', options:["ver 1", "ver 2"], required: true},
         {prompt: 'Which version is more entertaining?', name: 'entertain', options:["ver 1", "ver 2", "neither"], required: true},
      ],
      randomize_audio_order: true,
      randomize_question_order: false,
      show_transcript: true
   };
   timeline.push(pair_choice_block_2)
   return timeline
}